Archivos CSS todos en una carpeta

Archivos JS todos en una carpeta

Orden: Los archivos deberán estar ordenados correctamente en carpetas para facilitar la corrección.

Barra de navegación superior con links funcionales.

Implementación de galería de GIFs traídos dinámicamente desde la API de Giphy en el buscador y trendings .

Autocompletar con sugerencias desde la API al empezar a tipear en el buscador.

Sugerencias de trendings traídas desde la API y que accionen una búsqueda al hacer click.

Funcionalidad de la tarjeta: Fullscreen, Descargar y Favoritear.

Implementación de captura de video usando RecordRTC.js.

POST a la API de Giphy para subir los GIFs capturados.

Implementar LocalStorage para guardar Mis GIFOS y Favoritos.